# dsh-subagent-toolkit

## Preview

![Subagent settings](docs/subagent-settings.png)

![Model selection](docs/subagent-model-choice.png)

A DeepSeek Harness bundle for configuring **subagent models** without replacing the built-in DeepSeek Account provider.

## What it provides

- `subagent_pi` — a subagent tool backed by the official **Pi CLI** in one-shot mode.
  It runs `pi --print --no-session --no-context-files --no-extensions --no-mcp --no-skills`
  with the selected provider/model, so it never loads Pi Desktop's Maker or
  triggers its `codex exec` secondary delegation.
- **Settings → Subagent** — one linear flow:
  - choose a channel and optionally edit its Base URL and API key;
  - fetch the channel's model list;
  - choose exactly one model, or keep “Follow the main model”;
  - optionally tune that model's context window, max output tokens and reasoning efforts;
  - the Pi CLI provider/model lives in a collapsed Advanced section.

The plugin deliberately does **not** replace `deepseek-account` or
`subagent-model-selection-settings`. DeepSeek Account remains the native default;
Magpie and other providers are additional routes. Saving a single model writes a
one-route allowlist and adds a small system-prompt nudge so a new DSH session uses
that route for `subagent` calls.

## Install

Local checkout:

```sh
dsh plugin --profile desktop add /absolute/path/to/dsh-subagent-toolkit
# or, after the package tarball is built:
dsh plugin --profile desktop add ./dist/dsh-subagent-toolkit-0.2.0.tgz
```

Published npm package (after `pnpm publish`):

```sh
dsh plugin --profile desktop add dsh-subagent-toolkit
```

Then open **Settings → Subagent**.

## Channels

Channel configuration is available from the plugin page's **Add custom
OpenAI-compatible channel** form, and the same providers remain editable in
DSH's native **Settings → Models** page. DSH supports:

- the Magpie provider routes declared in `llm-pi-ai.providers`;
- an OpenAI-compatible custom provider with URL, API key, `Fetch available models`,
  per-model `contextWindow`, `maxTokens`, and `reasoningEfforts`.

The plugin page writes `llm-pi-ai.providers` and stores API keys through the
credential service. It reads the live model catalog produced by those providers,
so a channel added or changed in Models appears there automatically.

## Pi CLI defaults

`cordis.patch.yml` sets:

```yaml
- id: subagent-pi
  name: dsh-subagent-toolkit
  config:
    providerName: pi-cli
    binPath: pi
    provider: magpie
    model: ''
    tools: read,bash,edit,write
    agentDir: ''
```

- `binPath`: `pi` must resolve on PATH, or set an absolute path to the official
  `@earendil-works/pi-coding-agent` binary.
- `provider` / `model`: written from the Settings page. Leave `model` empty to
  use the Pi CLI's own default from its agent directory. The Pi CLI section is
  intentionally below the native subagent model flow.
- `nativeReasoningEffort`: the default thinking effort selected by the slider for
  the native subagent route; the generated system-prompt guidance passes it as
  `reasoning_effort` when delegating.
- `agentDir`: optional `PI_CODING_AGENT_DIR`. A dedicated directory containing
  `models.json` and `settings.json` is the cleanest way to keep Pi CLI settings
  separate from PI Desktop.
- `tools`: built-in Pi tools allowed in the child. Keep `Agent`/`Task` out of
  this list so the child stays single-layer.

If `model` is empty, `subagent_pi` uses the Pi CLI's current default. If the Pi
CLI default itself points at `codex/gpt-6.1-sol`, that is still a model call, not
PI Desktop's `codex exec`; the plugin never launches the Codex CLI.

## Market index

`market/index.example.json` is a minimal DSH plugin-index entry. Publish the
package to npm (or point to a Git commit), serve the index JSON plus its icons
from a static host, then add that URL under **Plugins → Discover → Add index
source**.

## Scope and known limits

- The UI writes a one-route allowlist plus a system-prompt nudge for the native
  `subagent` tool. If a deployment needs a hard default independent of model
  compliance, set `tool-subagent.agentOptions` in the profile as well.
- The Pi CLI child is an external one-shot process: it does not inherit the
  parent session, local Agent tools, or DSH Session records. Its final text is
  returned as the subagent result.
- The plugin executes the configured `pi` binary on your machine. Install only
  from a source you trust.
